CREATE FUNCTION  outUser(pid IN NUMBER)
  RETURN VARCHAR2
  AS
  t_name T_USER.U_NAME%TYPE ;
  BEGIN
    select U_NAME INTO t_name from T_USER WHERE U_ID=pid;
    RETURN  t_name;
  END;
/
