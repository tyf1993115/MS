CREATE PROCEDURE  sayYHSB
  AS 
  BEGIN 
    dbms_output.put_line('YH傻逼');
  END;
/
